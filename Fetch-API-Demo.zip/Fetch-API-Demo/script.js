// ── DOM Elements ──────────────────────────────────────────────
const fetchBtn = document.getElementById("fetchBtn");
const btnText = document.getElementById("btnText");
const statusBar = document.getElementById("statusBar");
const statusMsg = document.getElementById("statusMsg");
const errorBox = document.getElementById("errorBox");
const errorMsg = document.getElementById("errorMsg");
const dataContainer = document.getElementById("dataContainer");

const API_URL = "https://jsonplaceholder.typicode.com/users";

// ── Helpers ───────────────────────────────────────────────────
function setLoading(isLoading) {
  fetchBtn.disabled = isLoading;
  btnText.textContent = isLoading ? "Fetching…" : "Fetch Users";
  statusBar.classList.toggle("hidden", !isLoading);
  errorBox.classList.add("hidden");
}

function showError(message) {
  errorMsg.textContent = message;
  errorBox.classList.remove("hidden");
}

function getInitials(name) {
  return name
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
}

// ── Render one user card ──────────────────────────────────────
function createUserCard(user, index) {
  const card = document.createElement("div");
  card.className = "user-card";
  card.style.animationDelay = `${index * 50}ms`;

  card.innerHTML = `
    <div class="card-top">
      <div class="avatar">${getInitials(user.name)}</div>
      <div>
        <div class="card-name">${user.name}</div>
        <div class="card-username">@${user.username}</div>
      </div>
    </div>
    <div class="card-fields">
      <div class="card-field">
        <span class="field-label">email</span>
        <span class="field-value">
          <a href="mailto:${user.email}">${user.email}</a>
        </span>
      </div>
      <div class="card-field">
        <span class="field-label">phone</span>
        <span class="field-value">${user.phone}</span>
      </div>
      <div class="card-field">
        <span class="field-label">city</span>
        <span class="field-value">${user.address.city}</span>
      </div>
      <div class="card-field">
        <span class="field-label">company</span>
        <span class="field-value">${user.company.name}</span>
      </div>
      <div class="card-field">
        <span class="field-label">website</span>
        <span class="field-value">
          <a href="https://${user.website}" target="_blank">${user.website}</a>
        </span>
      </div>
    </div>
  `;

  return card;
}

// ── Fetch & Display ───────────────────────────────────────────
async function fetchUsers() {
  setLoading(true);
  dataContainer.innerHTML = "";

  try {
    // Step 4.2: Fetch data from API
    const response = await fetch(API_URL);

    if (!response.ok) {
      throw new Error(`HTTP error — status: ${response.status}`);
    }

    // Step 4.3: Convert response to JSON
    const users = await response.json();

    // Step 5.1: Dynamically create elements
    users.forEach((user, index) => {
      const card = createUserCard(user, index);
      dataContainer.appendChild(card);
    });

    statusMsg.textContent = `${users.length} users loaded.`;
  } catch (err) {
    // Step 5.2: Handle errors
    showError(`Failed to fetch data: ${err.message}`);
  } finally {
    setLoading(false);
  }
}

// Step 4.1: Add event listener
fetchBtn.addEventListener("click", fetchUsers);
